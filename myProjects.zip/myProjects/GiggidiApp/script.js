const submitBtn = document.getElementById('submit-btn')
const tableBody = document.getElementById('todo-table-body')
const errorAlert = document.getElementById('error-alert')

let SN = tableBody.lastElementChild.firstElementChild.innerText
console.log(SN);

submitBtn.addEventListener('click', () => {
    const userInput = document.getElementById('user-input').value
    const dTime = document.getElementById('d-time').value

    if (userInput === '') {
        errorAlert.classList.remove('d-none')
        errorAlert.innerText = 'Type Something'
    } else {
        errorAlert.classList.add('d-none')
        const tableRow = document.createElement('tr')
        tableRow.innerHTML = `
                        <td>${Number(++SN)} </td>
                        <td>${userInput}</td>
                        <td>${dTime}</td>
                        <td class="">
                            <input type="checkbox" style="transform: scale(2)" class="m-3">
                            <button class="btn btn-outline-dark">💯</button>
                        </td>`

                        tableBody.appendChild(tableRow)
    }
})