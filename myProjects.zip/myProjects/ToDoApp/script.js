const submitBtn = document.getElementById('submit-btn')
const errorAlert = document.getElementById('error-alert')
const tableBody = document.getElementById('todo-table-body')


// get all x-buttons 
let xBtns = document.querySelectorAll('.x-btn')

// Add event listeners to the x-buttons to remove the grandparent (TR) WHEN CLICKED 
xBtns.forEach( btn => {    
    btn.addEventListener('click', () => {
        btn.parentNode.parentNode.remove()
    })
});

// get all edit-buttons 
let editBtns = document.querySelectorAll('.edit-btn')

// Add event listeners to the edit-buttons to remove the grandparent (TR) WHEN CLICKED 
editBtns.forEach( btn => {    
    btn.addEventListener('click', () => {
        document.getElementById('user-input').value = btn.parentNode.parentNode.firstElementChild.nextElementSibling.innerText
        document.getElementById('e-time').value = btn.parentNode.parentNode.firstElementChild.nextElementSibling.nextElementSibling.innerText
        btn.parentNode.parentNode.remove()

    })
});



// get all checkbox-buttons 
const completedBtns = document.querySelectorAll('input[type="checkbox"]')

// Add event listeners to the checkbox-buttons mark (tick) WHEN CLICKED 
completedBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        btn.attributes.setNamedItem
        btn.setAttribute('checked', true)
        btn.setAttribute('disabled', true)
    })
})

let SN = tableBody.lastElementChild.firstElementChild.innerText



    
    
    
submitBtn.addEventListener('click', () => {
    
    const userInput = document.getElementById('user-input').value
    const eTime = document.getElementById('e-time').value
    
    if (userInput === ''){
        errorAlert.classList.remove('d-none')
        errorAlert.innerText = 'Input Text'
    } else {
        
        errorAlert.classList.add('d-none')
        const tableRow = document.createElement('tr')

        tableRow.innerHTML = `
            <td>${Number(++SN)}</td>
            <td> ${userInput}</td>
            <td>${eTime}</td>
            <td class="text-center">
                <input type="checkbox" name="completed" id="" class="btn btn-outline-primary">
                <button class="btn text-center x-btn    btn-outline-primary " > ❌ </button>
                <button class="btn text-center edit-btn   btn-outline-primary -0 ">🖊</button>
            </td>`
        tableBody.appendChild(tableRow)


        // ************* EVENT HANDLING FOR NEWLY ADDED ITEMS ****************
        const xxBtns = document.querySelectorAll('.xx-btn')

        xxBtns.forEach( btn => {
            btn.addEventListener('click', (e) => {
                btn.parentNode.parentNode.remove()
            })
        });


        // get all checkbox-buttons 
        const completedxBtns = document.querySelectorAll('input[type="checkbox"]')
        console.log(completedBtns);


        let editXBtns = document.querySelectorAll('.edit-btn')

        // Add event listeners to the edit-buttons to remove the grandparent (TR) WHEN CLICKED 
        editXBtns.forEach( btn => {    
            btn.addEventListener('click', () => {
                document.getElementById('user-input').value = btn.parentNode.parentNode.firstElementChild.nextElementSibling.innerText
                document.getElementById('e-time').value = btn.parentNode.parentNode.firstElementChild.nextElementSibling.nextElementSibling.innerText
                btn.parentNode.parentNode.remove()

            })
        });



        // Add event listeners to the checkbox-buttons mark (tick) WHEN CLICKED 
        completedxBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                btn.attributes.setNamedItem
                btn.setAttribute('checked', true)
                btn.setAttribute('disabled', true)
            })
        })
        

        document.getElementById('user-input').value = ''

    }
})